"""API stub for worker."""
