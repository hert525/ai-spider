"""V1 stub."""
