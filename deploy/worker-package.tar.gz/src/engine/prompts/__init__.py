"""Prompt templates."""
